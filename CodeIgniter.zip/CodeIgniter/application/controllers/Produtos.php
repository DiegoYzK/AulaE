<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Produtos extends CI_Controller{

    public function index() {
        
         echo "voce está no index";
     }
  
    public function list_tab() {
        
        $this->load->model("ProdMod", "prods");
        $resultado = $this->prods->List_todos();
        $dados = array("prods" => $resultado);
        $this->load->view("Vprod/ListTab", $dados);
        
    }
    
    public function cadastrar() {
        
        $this->load->model("ProdMod", "ProdMod");
        $this->form_validation->set_rules('produto', 'Produto', 'trim|required');
        $this->form_validation->set_rules('preco', 'Preço', 'trim|required'); 
        
        if($this->form_validation->run() == FALSE):
           $dados['formerror'] = validation_errors();
        else:
            
            $dados_form = $this->input->post();
            $this->ProdMod->manipula($dados_form['produto'], 
                    $dados_form['preco']);
            $dados['formerror'] = 'sucesso';
            
        endif;
        
        $this->load->view('cadastrar',$dados);
        
    }
}
