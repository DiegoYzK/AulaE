 <?php $this->load->view('Header'); ?>
        <h1>PRODUTOS</h1>
        <h3>Lista de Produtos</h3>
        <table>
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Nome</th>
                    <th>Preco</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach ($prods as $p){
                        echo "<tr>" .
                                "<td>" . $p->idprod . "</td>".
                                "<td>" . $p->nome . "</td>".
                                "<td>" . $p->preco . "</td>".
                            "<tr>";    
                                
                    }
                ?>
            </tbody>
        </table>
        
    </body>
</html>
