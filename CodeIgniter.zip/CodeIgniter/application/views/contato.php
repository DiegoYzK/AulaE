
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Envie sua Mensagem</h1>
        <?php
            echo validation_errors('formerror');
        ?>
        <?php echo form_open('contato'); ?>
        
        <h5>Produto</h5>
        <input type="text" name="produto" value="" size="50" />
        <h5>Preco</h5>
        <input type="text" name="preco" value="" size="50" />
        <div><input type="submit" value="Submit" /></div>
    </body>
</html>
