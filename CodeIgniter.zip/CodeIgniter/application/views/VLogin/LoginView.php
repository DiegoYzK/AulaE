 <?php $this->load->view('Header'); ?>
        <h1>Sistema de Login</h1> 
        <?php echo validation_errors('formerror');?>
        <?php echo form_open('login');?>
        <h5>Usuario</h5>
        <input type="text" name="login" value="" size="50" />
        <h5>Senha</h5>
        <input type="text" name="senha" value="" size="50" />
        <BR><BR>
        <div><input type="submit" value="LOGIN" /></div>
    </body>
</html>