<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="<?php echo base_url();?>/assets/css/newcss.css" rel="stylesheet"/>
    </head>
    <body>
        <h1>SISTEMA DE LOGIN</h1> 
        <?php echo validation_errors('formerror');?>
        <?php echo form_open('login');?>
        <h5>Usuario</h5>
        <input type="text" name="login" value="" size="50" />
        <h5>Senha</h5>
        <input type="text" name="senha" value="" size="50" />
        <BR><BR>
        <div><input type="submit" value="LOGIN" /></div>
    </body>
</html>