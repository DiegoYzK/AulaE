<html>
    <head>
        <meta charset="UTF-8">
        <link href="<?php echo base_url();?>/assets/css/newcss.css" rel="stylesheet"/>
        <title></title>
    </head>
    <body>
        <ol>
            <li> <a href="<?php echo base_url('produtos');?>">Home</a></li>
            <li> <a href="<?php echo base_url('itens');?>">Lista Produtos</a></li>
            <li> <a href="<?php echo base_url('cadastrar');?>">Cadastrar Produtos</a></li>
            <li> <a href="<?php echo base_url('login');?>">Autenticação</a></li>
        </ol>
        
