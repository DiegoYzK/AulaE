<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class UsuarioMod extends CI_Model{
    function valida_login($usuario, $senha){
        $this->db->where('login', $usuario);
        $this->db->where('senha', $senha);

        $query = $this->db->get('tb_usuario');

        if($query->num_rows ==1){
            return true;
        }
    }
}