<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class UsuMod extends CI_Model{
    
    function valid_login(){
        
        $this->db->where('Usuario',$this->input->post('usuario'));
        $this->db->where('Senha',$this->input->post('senha'));
        $query = $this->db->get('tb_login');
    }
}
