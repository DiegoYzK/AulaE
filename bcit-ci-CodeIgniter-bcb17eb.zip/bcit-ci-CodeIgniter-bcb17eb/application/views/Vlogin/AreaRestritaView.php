
<?php $this->load->view('Header'); ?>

        <h1>AREA RESTRTITA</h1>
        <p> Bem Vindo <?php echo $usuario ?> </p>

    </body>
</html>