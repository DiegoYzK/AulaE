
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/newcss.css">
    </head>
    <body>
        <ol>
            <li type="none"><a href="<?php echo base_url(''); ?>" >Inicio</a></li>
            <li type="none"><a href="<?php echo base_url('itens'); ?>" >Listar Produtos</a></li>
            <li type="none"><a href="<?php echo base_url('cadastrar'); ?>">Cadastrar Produtos</a></li>
            <li type="none"><a href="<?php echo base_url('login'); ?>">Autenticacao</a></li>
        </ol>

        