<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ProdMod extends CI_Model {

    public function List_todos() {
        $this->db->select("idprod, nome, preco");
        $resultado = $this->db->get("tb_prod")->result();
        return $resultado;
    }

    public function manipula($nomeprod, $precoprod) {
        $this->db->where('nome', $nomeprod);
        $this->db->select("idprod, nome, preco");
        $query = $this->db->get("tb_prod", 1);
        

        if ($query->num_rows() == 1):
            $this->db->set('nome', $nomeprod);
            $this->db->set('preco', $precoprod);
            $this->db->where('nome', $nomeprod);
            $this->db->update('tb_prod');
            $dados['formerror'] = 'Atualizado com sucesso';
            return $dados['formerror'];
        else:
            $dados = array(
                'nome' => $nomeprod,
                'preco' => $precoprod
            );
            $this->db->insert('tb_prod', $dados);
            $dados['formerror'] = 'Inserido com sucesso';
            return $dados['formerror'];
        endif;
    }

}
