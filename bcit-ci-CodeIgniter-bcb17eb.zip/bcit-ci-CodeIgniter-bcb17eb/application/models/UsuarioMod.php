<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class UsuarioMod extends CI_Model{
    function valida_login($usuario, $senha){

        $this->db->where('Usuario', $usuario);
        $this->db->where('Senha', $senha);
        $this->db->select('Usuario, Senha');
        $resultado = $this->db->get('tb_usuario')->result();

        var_dump($resultado);
        die();        

        $query = $this->db->get('tb_usuario');

        if($query->num_rows ==1){
            $this->session->set_userdata($usuario);
            redirect('VLogin/AreaRestritaView', $usuario);
            return true;
        } else{
            return false;
        }
    }
}