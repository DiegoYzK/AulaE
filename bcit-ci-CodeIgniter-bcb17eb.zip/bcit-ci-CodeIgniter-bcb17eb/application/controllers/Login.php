<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    
    function index(){
        $this->load->library('form_validation');
        $this->form_validation->set_rules('login', 'Login', 'trim|required');
        $this->form_validation->set_rules('senha', 'Senha', 'trim|required');

        $this->load->model("UsuarioMod", "USR");

        $this->load->view('Vlogin/LoginView.php');

        if($this->form_validation->run() == FALSE):
            $dados['formerror'] = validation_errors();
         else:
            
             $dados_form = $this->input->post();
             $this->USR->valida_login($dados_form['login'], $dados_form['senha']);
             $dados['formerror'] = 'sucesso';
         endif;
         
    }
   
}